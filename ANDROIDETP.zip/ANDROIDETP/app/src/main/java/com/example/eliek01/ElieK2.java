package com.example.eliek01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class ElieK2 extends AppCompatActivity {

    private ImageButton imgbt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elie_k2);

        this.imgbt = findViewById(R.id.imgbt);
        imgbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent kaka = new Intent(getApplication(),MainActivity.class);
                startActivity(kaka);
                finish();
            }
        });

    }
}
