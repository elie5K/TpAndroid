package com.example.eliek0tweb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // La méthode est appelée lorsque l'utilisateur clique sur le bouton "Aller Google".
    public void goGoogle(View view)  {
        String url="http://google.com";

        // Une intention implicite, demande une URL.
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        this.startActivity(intent);
    }

    // La méthode est appelée lorsque l'utilisateur clique sur le bouton "Envoyer un courrier électronique".
    public void sendEmail(View view)  {

        // Liste des destinataires
        String[] recipients=new String[]{"friendemail@gmail.com"};


        String subject="Hi, how are you!";


        String content ="This is my test email";

        Intent intentEmail = new Intent(Intent.ACTION_SEND, Uri.parse("mailto:"));
        intentEmail.putExtra(Intent.EXTRA_EMAIL, recipients);
        intentEmail.putExtra(Intent.EXTRA_SUBJECT, subject);
        intentEmail.putExtra(Intent.EXTRA_TEXT, content);

        intentEmail.setType("text/plain");

        startActivity(Intent.createChooser(intentEmail, "Choose an email client from..."));
    }



}