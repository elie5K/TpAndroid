package com.example.elieaf;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SALUTATION extends AppCompatActivity {


    private String firstName;
    private String lastName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_salutation );

        // Intent is passed into
        Intent intent = this.getIntent();

        this.firstName= intent.getStringExtra("firstName");
        this.lastName = intent.getStringExtra("lastName");

        String greeting = " Bonjour "+ firstName+" "+ lastName;

        TextView textGreeting =( TextView) this.findViewById(R.id.textsalut);

        textGreeting.setText(greeting);
    }

    // Une fois cette activité terminée, envoyez des commentaires à l'appelant.


    @Override
    public void finish() {
        // Préparer l'intention des données
        Intent data = new Intent();
        data.putExtra("feedback", " Je suis "+ this.firstName+", Salut!");
        // Activité terminée ok, retourne les données
        this.setResult( Activity.RESULT_OK, data);
        super.finish();
    }

    // La méthode est appelée lorsque l'utilisateur clique sur le bouton Précédent.
    public void backClicked(View view)  {
        /* Appel de onBackPressed ().
         Gi phương thức onBackPressed ()*/
        this.onBackPressed();
    }
}
