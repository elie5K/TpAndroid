package com.example.elieaf;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

     private EditText texfirst;
     private EditText texlast;
     private TextView texretour;

    public static final int MY_REQUEST_CODE = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        this.texfirst = (EditText)this.findViewById(R.id.Text_first);
        this.texlast = (EditText)this.findViewById(R.id.Text_last);
        this.texretour = (TextView)this.findViewById(R.id.text_Retour);

      /* lorsque l'activité de message d'aceuil est terminé, il renvoie un retour
      si vous l'avez demarer par staractivityresultat
       */
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode == MY_REQUEST_CODE ) {
            String feedback = data.getStringExtra("feedback");
            this.texretour.setText(feedback);
        } else {
            this.texretour.setText("!?");
        }
    }

    // La méthode est appelée lorsque l'utilisateur clique sur le bouton "Afficher le message d'accueil".
    public void showGreeting(View view)  {
        String firstName= this.texfirst.getText().toString();
        String lastName= this.texlast.getText().toString();

        Intent intent = new Intent(this,SALUTATION.class);
        intent.putExtra("firstName", firstName);
        intent.putExtra("lastName", lastName);



        /* Démarrer l'activité et pas besoin de commentaires.
        // this.startActivity (intent);
 
        // Démarrer l'activité et obtenir des commentaires.*/

        this.startActivityForResult(intent, MY_REQUEST_CODE);

    }
}

